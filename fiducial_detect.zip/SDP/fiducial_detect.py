import cv2
import cv2.aruco as aruco
import numpy as np

# Define Aruco marker parameters
ARUCO_DICT = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
MARKER_IDS = [0, 1, 2, 3, 4]  # IDs for 5 markers
MARKER_SIZE = 200  # Size of markers in pixels

# Function to generate and save Aruco markers
def generate_aruco_markers():
    for marker_id in MARKER_IDS:
        marker = aruco.generateImageMarker(ARUCO_DICT, marker_id, MARKER_SIZE)
        cv2.imwrite(f"marker_{marker_id}.png", marker)
    print("Markers saved as PNG files.")

# Function to detect Aruco markers and return their coordinates
def detect_aruco_markers(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    corners, ids, _ = aruco.detectMarkers(gray, ARUCO_DICT)

    marker_positions = {}

    if ids is not None:
        for i, marker_id in enumerate(ids.flatten()):
            # Get the center of the marker
            corner_points = corners[i].reshape(4, 2)
            center_x = int(np.mean(corner_points[:, 0]))
            center_y = int(np.mean(corner_points[:, 1]))
            marker_positions[marker_id] = (center_x, center_y)

            # Draw marker outline and center
            cv2.polylines(frame, [corner_points.astype(int)], True, (0, 255, 0), 2)
            cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
            cv2.putText(frame, f"ID: {marker_id}", (center_x + 10, center_y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

    return frame, marker_positions

# Main function to capture video and detect markers
def main():
    generate_aruco_markers()

    # Start video capture
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open video capture.")
        return

    print("Press 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        # Detect Aruco markers
        frame, marker_positions = detect_aruco_markers(frame)

        # Print relative coordinates
        if len(marker_positions) == len(MARKER_IDS):
            print("Relative positions:")
            for marker_id, position in marker_positions.items():
                print(f"Marker {marker_id}: {position}")

        # Display the frame
        cv2.imshow("Aruco Marker Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
